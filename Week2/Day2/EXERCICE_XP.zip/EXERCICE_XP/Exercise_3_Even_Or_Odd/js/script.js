let X = prompt("Entrez un nombre")
if(X%2==0){
    alert(X+ " is an even number")
}else{
    alert(X + " is an odd number")
}