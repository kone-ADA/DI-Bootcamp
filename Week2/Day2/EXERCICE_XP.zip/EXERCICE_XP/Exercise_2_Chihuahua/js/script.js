let newDog = "Chihuahua";
console.log("the number of letters in Chihuahua is "+ newDog.length)
console.log(newDog.toUpperCase())
console.log(newDog.toLowerCase())
if(newDog == "Chihuahua"){
    console.log("I love Chihuahuas, it’s my favorite dog breed")
}else{
    console.log("I dont care, I prefer cats")
}